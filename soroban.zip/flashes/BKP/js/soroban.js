//var d = document;
var flashColor = 'teal';
var flashFontColor = 'teal-text text-accent-1';
var resultFlashColor = 'green lighten-4	';
var resultFlashFontColor = 'teal-text text-lighten-1';

var result = 0;

var numbers = [];


//$(document).ready();


async function sleep (forHowLong) {
  function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  };
  await timeout(forHowLong);
}






function createLines() {
	var numberOfLines = $('#numberOfFlahes').val();
	var number;

	for(i=0;i<numberOfLines;i++){
		//console.log(numberOfLines);
		var line = d.createElement("li");
		line.className = 'collection-item right-align';
		line.id = 'line';
		line.name = 'line';
		number = createNumber();
		line.text = number;
		line.val = number;
		// $('#lines').append(line);
		$('#lines').append("<li class='collection-item right-align' id='line'><a href='#!' id='number' class='collection-item' value='"+number+"'>"+number+"</a></li>");
		numbers.push(number);

			
	};   
}





function createNumber() {
	var numberOfDigits = $('#numberOfDigits').val();

	var number;
	var minToSum;
	var maxToSum;
	var minDigitsToSum;
	var operation;
	var operator;

	if(numberOfDigits==1){
		number = parseInt(Math.random()*9)+1;
		//return number;
	}else{
		minToSum = "9"
		minDigitsToSum = numberOfDigits-1;
		for(ii=1;ii<minDigitsToSum;ii++){
			minToSum = minToSum+"9";
		};
		

		maxToSum = "9";
		maxDigitsToSum = numberOfDigits-1;
		for(ii=1;ii<maxDigitsToSum;ii++){
			maxToSum = maxToSum+"9";
		};
		maxToSum=maxToSum+"9";


		number = Math.random()
		number = parseInt(number*(maxToSum));
		if (number<=minToSum){
			number=parseInt(number)+parseInt(minToSum);
		};
		
		if (number>=1000){
			console.log('passou do maximo');
		};
		
       };
		operator = getOperation()
		operation = result+operator+number;
		result = eval(operation);

		var allowNegativeResultCbx = $('input[type=checkbox][id=allowNegative]');
		var allowNegativeResult = allowNegativeResultCbx[0].checked
		//var allowNegativeResult = $('input[type=checkbox][id=allowNegative]').checked;

		if(result<0 && !allowNegativeResult){
			result = eval(result+'+'+number+'+'+number)
			return number;
		}else{
			if(operator=='-'){
				return '-'+number;
			}else{
				return number;
				};
		};
	
		


	// // return number;
}








 function createFlash(number,color,fontColor) {

	var div = d.createElement("div");


	$('#flashes').append(div);


	$('#flashes').addClass(flashColor);
	$('#flashes').addClass('valign-wrapper');

	div.id = 'divFlash';
	div.name = 'divFlash';

	
	var numberLength = (number.toString()).length;

	var pWidth = $('#divFlash').width();

	fontSize = 700*(3/parseInt(numberLength));

	fontSize = fontSize*(pWidth/1920);


	fontSize = fontSize + 'px';


	$('#divFlash').text(number);
	$('#divFlash').css('text-align', 'center');
	$('#divFlash').css('font-size', fontSize);
	$('#divFlash').css('margin', 'auto');
	$('#divFlash').addClass(color);
	$('#divFlash').addClass(fontColor);

};

async function showFlashes(){

	var interval = $('#interval').val()
	var duration = $('#duration').val()

	$('#flashes').removeClass('hide');
	$('#columnOfConfigs').addClass('hide');


	//countdown
		createFlash('Get ready','red accent-1','black-text');
		await sleep(1000);
		$('#divFlash').remove();
		await sleep(250);

		createFlash('Set','amber lighten-3','black-text');
		await sleep(1000);
		$('#divFlash').remove();
		await sleep(250);

		createFlash('GO!','green  accent-1','black-text');
		await sleep(650);
		$('#divFlash').remove();
		await sleep(750);



	//show flashes
	for(iiii=0;iiii<numbers.length;iiii++){
		createFlash(numbers[iiii], flashColor,flashFontColor);
		await sleep(duration*1000);
		$('#divFlash').remove();
		await sleep(interval*1000);
	};

	//show show result buttom
	$('#showResult').removeClass("hide");



	//add a green result line to the list
	var line = d.createElement("li");
	line.className = 'collection-item right-align green lighten-4';
	line.id = 'line';
	line.name = 'line';
	line.text = "Result = "+result;

	$('#lines').append("<li class='collection-item right-align' id='line'><a href='#!' class='collection-item green lighten-4'>"+result+"</a></li>");

};






function getOperation() {
	var numberOfOperations = $('input[type=checkbox][id=operations]:checked').length
	var operations = $('input[type=checkbox][id=operations]:checked');

	for(iii=0;iii<numberOfOperations;iii++){
		var operation
		if(numberOfOperations>1){
			operation=parseInt(Math.round(Math.random())*(numberOfOperations-1));
		}else{
			operation = (numberOfOperations-1);
		}
		return operations[operation].value;
	}	
}

function resetLines(){
	var lines = $('#line');
	var qtdeLines = lines.length
	//result=0;
	
	$('#divFlash').remove();

	while (qtdeLines==1){
		var lines2 = $('#line');
		if(lines2.length>0){
			lines2.remove();
		}else{
			qtdeLines=0;
		}
		
	}
	createLines();	
}










$('input[type=checkbox][id=operations][name=addition]').click(function(){
	if(!this.checked){
		if(!$('input[type=checkbox][id=operations][name=subtraction]').checked){
			$('input[type=checkbox][id=operations][name=subtraction]').prop("checked", true);
			$('input[type=checkbox][id=allowNegative]').removeAttr("disabled");
			$('input[type=checkbox][id=allowNegative]').prop("checked",true);
		}
	}
});


$('input[type=checkbox][id=operations][name=subtraction]').click(function(){
	if(this.checked){
		$('input[type=checkbox][id=allowNegative]').removeAttr("disabled");
		if($('input[type=checkbox][id=operations][name=addition]').checked){
			$('input[type=checkbox][id=allowNegative]').removeAttr("disabled");
			$('input[type=checkbox][id=allowNegative]').prop("checked",true);
		}else{
			// $('input[type=checkbox][id=operations][name=addition]').prop("checked",true);
		}

	}else{
		if(!$('input[type=checkbox][id=operations][name=addition]').checked){
			$('input[type=checkbox][id=operations][name=addition]').prop("checked",true);
		}
		$('input[type=checkbox][id=allowNegative]').prop("checked", false);
		$('input[type=checkbox][id=allowNegative]').attr("disabled", true);

	}

});


$('input[type=checkbox][id=allowNegative]').click(function(){
	if(!this.checked){
		$('input[type=checkbox][id=operations][name=addition]').prop("checked",true);	
	}
});

$('#generateBtn').click(function(){

	//reset numbers and results
	numbers = [];
	result = 0;

	//hide start button
	$('#generateBtn').addClass("hide");

	//hide show result button
	$('#showResult').addClass("hide");


	resetLines();
	showFlashes();

	//hide the lines
	$('#columnOfLines').addClass("hide");

});


$('#showResult').click(function(){

	//hide commands
	$('#columnOfConfigs').addClass('hide');

	//hide lines
	$('#columnOfLines').addClass('hide');

	//show the result flash
	// $('#divFlash').removeClass('hide');
	$('#flashes').removeClass('hide');

	//create a result flash
	createFlash(result, resultFlashColor,resultFlashFontColor);

	//hide show result button
	$('#showResult').addClass("hide");

	//show new exercise button
	$('#newExercise').removeClass("hide");


	//show the New Exercice button
	// $('#newExercise').removeClass("hide");

	//show the lines
	// $('#columnOfLines').removeClass("hide");

});





$('#newExercise').click(function(){

	//hide the New Exercise button
	$('#newExercise').addClass("hide");

	//show the show result button
	$('#showResult').removeClass("hide");

	//show start button
	$('#generateBtn').removeClass("hide");

	//hide the divFlash

	//show commands
	$('#showResult').removeClass("hide");
	$('#columnOfConfigs').removeClass('hide');
	
	//resetLines();
	
	//delete divFlash();
	$('#divFlash').remove();

	//hide flashes area
	$('#flashes').addClass('hide');


	//show the lines
	$('#columnOfLines').removeClass("hide");


});

// $('#numberOfDigits').change(function(){

// 	$('#newExercise').addClass("hide");
// 	$('#showResult').removeClass("hide");
// 	resetLines();


// });


// $('#numberOfLines').change(function(){

// 	$('#newExercise').addClass("hide");
// 	$('#showResult').removeClass("hide");
// 	resetLines();


// });


