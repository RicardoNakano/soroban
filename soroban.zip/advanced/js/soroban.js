var d = document;


var result = 0;

createLines();



function createLines() {
	var numberOfLines = $('#numberOfLines').val();
	var number;

	for(i=0;i<numberOfLines;i++){
		//console.log(numberOfLines);
		var line = d.createElement("li");
		line.className = 'collection-item right-align';
		line.id = 'line'
		line.name = 'line'
		number = createNumber();
		line.text = number;
		line.val = number;
		// $('#lines').append(line);
		$('#lines').append("<li class='collection-item right-align' id='line'><a href='#!' class='collection-item'>"+number+"</a></li>");
		// $('#lines').append("<li class='collection-item right-align' id='line'>"+number+"</li>");
		//document.getElementById("lines").appendChild(line);

		// var linesHeight = $('#lines').height();
		// var configsAndLinesRowHeight = $('#configsAndLinesRow').height();
		// if(linesHeight>configsAndLinesRowHeight){
		// 	configsAndLinesRowHeight=linesHeight;
		// 	$('#columnOfLines').css('bottom','');
		// 	$('#columnOfLines').css('top','12%');

		// }else{
		// 	$('#columnOfLines').css('bottom','5%');
		// 	$('#columnOfLines').css('top','');			
		// }
		
	}   
}

function createNumber() {
	var numberOfDigits = $('#numberOfDigits').val();

	var number;
	var minToSum;
	var maxToSum;
	var minDigitsToSum;
	var operation;
	var operator;
	
	if(numberOfDigits==1){
		number = parseInt(Math.random()*9)+1;
		//return number;
	}else{

	minToSum = "9"
	minDigitsToSum = numberOfDigits-1;
	for(ii=1;ii<minDigitsToSum;ii++){
		minToSum = minToSum+"9";
	}
	

	maxToSum = "9";
	maxDigitsToSum = numberOfDigits-1;
	for(ii=1;ii<maxDigitsToSum;ii++){
		maxToSum = maxToSum+"9";
	}
	maxToSum=maxToSum+"9";


	number = Math.random()
	number = parseInt(number*(maxToSum));
	if (number<=minToSum){
		number=parseInt(number)+parseInt(minToSum);
	}
	
	if (number>=1000){
		console.log('passou do maximo');
	}
	
    }

	operator = getOperation()
	operation = result+operator+number;
	result = eval(operation);

	var allowNegativeResultCbx = $('input[type=checkbox][id=allowNegative]');
	var allowNegativeResult = allowNegativeResultCbx[0].checked
	//var allowNegativeResult = $('input[type=checkbox][id=allowNegative]').checked;

	if(result<0 && !allowNegativeResult){
		result = eval(result+'+'+number+'+'+number)
		return number;
	}else{
		if(operator=='-'){
			return '-'+number;
		}else{
			return number;
			}
	}
		


	// // return number;
}

function getOperation() {
	var numberOfOperations = $('input[type=checkbox][id=operations]:checked').length
	var operations = $('input[type=checkbox][id=operations]:checked');

	for(iii=0;iii<numberOfOperations;iii++){
		var operation
		if(numberOfOperations>1){
			operation=parseInt(Math.round(Math.random())*(numberOfOperations-1));
		}else{
			operation = (numberOfOperations-1);
		}
		return operations[operation].value;
	}	
}

function resetLines(){
	var lines = $('#line');
	var qtdeLines = lines.length
	result=0;
	
	while (qtdeLines==1){
		var lines2 = $('#line');
		if(lines2.length>0){
			lines2.remove();
		}else{
			qtdeLines=0;
		}
		
	}
	createLines();	
}


$('input[type=checkbox][id=operations][name=addition]').click(function(){
	if(!this.checked){
		if(!$('input[type=checkbox][id=operations][name=subtraction]').checked){
			$('input[type=checkbox][id=operations][name=subtraction]').prop("checked", true);
			$('input[type=checkbox][id=allowNegative]').removeAttr("disabled");
			$('input[type=checkbox][id=allowNegative]').prop("checked",true);
		}
	}
});


$('input[type=checkbox][id=operations][name=subtraction]').click(function(){
	if(this.checked){
		$('input[type=checkbox][id=allowNegative]').removeAttr("disabled");
		if($('input[type=checkbox][id=operations][name=addition]').checked){
			$('input[type=checkbox][id=allowNegative]').removeAttr("disabled");
			$('input[type=checkbox][id=allowNegative]').prop("checked",true);
		}else{
			// $('input[type=checkbox][id=operations][name=addition]').prop("checked",true);
		}

	}else{
		if(!$('input[type=checkbox][id=operations][name=addition]').checked){
			$('input[type=checkbox][id=operations][name=addition]').prop("checked",true);
		}
		$('input[type=checkbox][id=allowNegative]').prop("checked", false);
		$('input[type=checkbox][id=allowNegative]').attr("disabled", true);

	}

});


$('input[type=checkbox][id=allowNegative]').click(function(){
	if(!this.checked){
		$('input[type=checkbox][id=operations][name=addition]').prop("checked",true);	
	}
});

$('#generateBtn').click(function(){

	$('#newExercise').addClass("hide");
	$('#showResult').removeClass("hide");
	resetLines();

});


$('#showResult').click(function(){

	$('#newExercise').removeClass("hide");
	$('#showResult').addClass("hide");
	var line = d.createElement("li");
	line.className = 'collection-item right-align green lighten-4';
	line.id = 'line'
	line.name = 'line'
	line.text = "Result = "+result;
	// $('#lines').append(line);
	$('#lines').append("<li class='collection-item right-align' id='line'><a href='#!' class='collection-item green lighten-4'>"+result+"</a></li>");
	// $('#lines').append("<li class='collection-item right-align green lighten-4' id='line'>Result = "+result+"</li>");



});

$('#newExercise').click(function(){

	$('#newExercise').addClass("hide");
	$('#showResult').removeClass("hide");
	resetLines();


});

$('#numberOfDigits').change(function(){

	$('#newExercise').addClass("hide");
	$('#showResult').removeClass("hide");
	resetLines();


});


$('#numberOfLines').change(function(){

	$('#newExercise').addClass("hide");
	$('#showResult').removeClass("hide");
	resetLines();


});

