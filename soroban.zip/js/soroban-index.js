//noinspection JSUnresolvedFunction
$(document).ready(function(){
    //noinspection JSUnresolvedFunction
    $("#zero").click(function(){
        //noinspection JSUnresolvedFunction
        document.getElementById("iframe").contentWindow.soroban.init();
    });
});