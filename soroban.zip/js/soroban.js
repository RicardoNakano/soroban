/**
 * Soroban script
 * (C) 2015 Michał Ciołczyk
 */

COLUMNS = 15;
EARTH_ELEMENTS_COUNT = 4;
ELEMENT_WIDTH = 55;
ELEMENT_HEIGHT = 32;
SEPERATOR_HEIGHT = 150;
SEPERATOR_WIDTH = 15;
ELEMENT_SRC = "img/element4.png";
DELTA = 2 * ELEMENT_HEIGHT;
BAR_SRC = "img/bar.png";
BAR_HEIGHT = "100%";
BAR_WIDTH = 8;
cal_pos = [];
cal_pos["4"]=3;
cal_pos["3"]=2;
cal_pos["2"]=1;
cal_pos["1"]=0;
cal_pos_up=[];
cal_pos_up["5"]=1;

var $divClone;

var mov_val = [];
var resets = 0;
var xx = 0;
var COLs = 0;
var COLs_a = 0;


var soroban = {
    value: 0,
    els: [],
    
    init: function () {
        console.log('entrou no init function')

        soroban.calculate();

        this.els = [];
        //noinspection JSJQueryEfficiency,JSUnresolvedFunction
        // $("#soroban").html("");

        //create elements array
        for (var i = 0; i < COLUMNS; i++) {

            this.els.push([]);

            for (var j = 0; j < EARTH_ELEMENTS_COUNT; j++) {
                //create array of Earth elements
                var el = $("<img />");
                el.attr("src", ELEMENT_SRC);
                el.css("left", (i * (SEPERATOR_WIDTH + ELEMENT_WIDTH) + 10) + "px");
                el.css("top", (ELEMENT_HEIGHT * (j + 1) + SEPERATOR_HEIGHT) + "px");
                el.css("position", "absolute");
                el.attr("data-i", i);
                el.attr("data-j", j);
                el.attr("data-moved", 0);
                el.addClass("element");
                // $(el).click(function () {


                //move Earth elements if digit if < 4 or >5 (smaller than 4 or bigger than 5)
                $(".btn-success").click(function () {
                    //hide Result button
                    $(".btn-success").hide();
                    
                    //show Reset button
                    $(".btn-danger").show();
                    
                    //show result area
                    $(".cal_result").show();

                    var i = parseInt($(this).attr("data-i"));
                    var j = parseInt($(this).attr("data-j"));
                    var a = ["4","3","1"];
                    COLs = COLUMNS-mov_val.length;
                    h = 0;
                    for(var k=COLs;k<COLUMNS;k++){
                        if(parseInt(cal_pos[mov_val[h]])<4){
                            soroban.clickEarthElement(k,parseInt(cal_pos[mov_val[h]])+1);
                        }else{
                            if(parseInt(mov_val[h])>5){
                                var b = parseInt(mov_val[h])-5;
                                soroban.clickEarthElement(k,b);
                            }
                        }
                        h++;
                    }

                });

                this.els[i].push(el);
            }






            //create array of Heaven elements
            var el = $("<img />");
            el.attr("src", ELEMENT_SRC);
            el.css("left", (i * (SEPERATOR_WIDTH + ELEMENT_WIDTH) + 10) + "px");
            el.css("top", 0 + "px");
            el.css("position", "absolute");
            el.attr("data-i", i);
            el.attr("data-j", EARTH_ELEMENTS_COUNT);
            el.attr("data-moved", 0);
            el.addClass("element");
            // el.click(function () {


            //move elements if digit is = 5 or >5 (equal 5 or bigger than 5)
            $(".btn-success").click(function () {
                var i = parseInt($(this).attr("data-i"));
                var   bigyo = 0;
                COLs_a = COLUMNS-mov_val.length;
                h = 0;
                for(var k=COLs_a;k<COLUMNS;k++){
                    if(parseInt(mov_val[h])==5){
                        soroban.clickHeavenElement(k);
                    }else{
                        if(parseInt(mov_val[h])>5){
                           soroban.clickHeavenElement(k);
                        }
                    }
                    h++;
                }
            });


            this.els[i].push(el);
        }//end of create elements array

        //append elements of array in soroban area
        for (var c in this.els) {
            //noinspection JSUnfilteredForInLoop
            var column = this.els[c];
            for (var e in column) {
                //noinspection JSUnfilteredForInLoop
                var element = column[e];
                //noinspection JSUnresolvedFunction
                $("#soroban").append(element);
            }
        };

        //create rods array
        for(var i = 0; i < COLUMNS; i++) {
            //noinspection JSUnresolvedFunction,JSDuplicatedDeclaration
            var bar = $("<img />");
            bar.attr("src", BAR_SRC);
            bar.css("width", BAR_WIDTH);
            bar.css("height", BAR_HEIGHT);
            bar.css("position", "absolute");
            bar.css("top", 0);
            bar.css("z-index", -1);
            bar.css("left", (i * (SEPERATOR_WIDTH + ELEMENT_WIDTH) + (ELEMENT_WIDTH - BAR_WIDTH) / 2 + 10) + "px");
            //append rods to soroban area
            $("#soroban").append(bar);
        };

        //create top botton elements seraparatos
        var bar = $("<img />");
        bar.attr("src", BAR_SRC);
        bar.css("width", BAR_HEIGHT);
        bar.css("height", BAR_WIDTH);
        bar.css("position", "absolute");
        bar.css("top", (DELTA + ELEMENT_HEIGHT + 5) + "px");
        bar.css("z-index", -1);
        bar.css("left", 0);
        //append separator to soroban area
        $("#soroban").append(bar);
        console.log($("#soroban"));

    },//end of init: function()

    calculate:function(){
        //$('.row-soroban').html($divClone);
        var operator = [];
        operator["plus"]="+";
        operator["minus"]="-";
        operator["multiply"]="*";
        operator["divide"]="/";

        var random1 = 0;
        var random2 = 0;

        $("#ex1").change(function(e){
            $(".cal_result").hide();
            $(".ext1_display").text("");
            $(".cal_result").text("");
            var ext1 = e.target.value;
            var ext1_count=1;
            for(i=0;i<ext1;i++){
                ext1_count = ext1_count*10;
            }
            random1 = Math.floor((Math.random() * ext1_count) + 1);
            // $(".ext1_display").append("<font color='blue' size='8'>"+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+random1+"</font>");
            var input = $("input:radio");
            // console.log(input[0].checked);
            for(i=0;i<input.length;i++){
                if(input[i].checked){
                    var opt = operator[input[i].id];
                    $(".ext1_display").append("<font color='blue' size='6'>"+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+random1+"</font>");
                    $(".cal_result").append("<font color='red' size='6'>"+"result"+"&nbsp;&nbsp;&nbsp;&nbsp"+Math.floor(eval(random1+opt+random2))+"</font>");
                    var str_result = Math.floor(eval(random1+opt+random2));
                    mov_val = str_result.toString().split("");
                }
            }
            //show Result button
            //$(".btn-success").show();

            //hide Reset button
            //$(".btn-danger").hide();
            
            
        })

        $("#ex2").change(function(e){
            $(".cal_result").hide();
            $(".ext2_display").text("");
            $(".cal_result").text("");
            var ext2 = e.target.value;
            var ext2_count=1;
            for(i=0;i<ext2;i++){
                ext2_count = ext2_count*10;
            }
            random2 = Math.floor((Math.random() * ext2_count) + 1);
            var input = $("input:radio");
            // console.log(input[0].checked);
            for(i=0;i<input.length;i++){
                if(input[i].checked){
                    var opt = operator[input[i].id];
                    $(".ext2_display").append("<font color='blue' size='6'>"+(opt=='*'?'×':opt=='/'?'÷':opt)+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+random2+"</font>");
                    $(".cal_result").append("<font color='red' size='6'>"+"result"+"&nbsp;&nbsp;&nbsp;&nbsp"+Math.floor(eval(random1+opt+random2))+"</font>");
                    var str_result = Math.floor(eval(random1+opt+random2));
                    mov_val = str_result.toString().split("");
                }
            }
            // console.log($("input:radio")[0].id);
            // cal_result
            //show Result button
            //$(".btn-success").show();

            //hide Reset button
            //$(".btn-danger").hide(); 
            
            
        })        
        
        $(".btn-danger").click(function(){
            //show Result button
            //$(".btn-success").show();

            //hide Reset button
            //$(".btn-danger").hide();
            
            //reset soroban
            //$("#soroban").text("");
            //$(".cal_result").text("");
            //soroban.init();

            // $(".ext1_display").text("");
            // $(".ext2_display").text("");
            // $(".cal_result").text("");
            // var k = 0;
            // soroban.clickEarthElement(14,0);
            // // console.log('bbbbbb',COLs);
            // // for(var i=COLs;i<COLUMNS;i++){
            // //     if(parseInt(cal_pos[mov_val[k]])<4){
            // //         soroban.clickEarthElement(i,parseInt(cal_pos[mov_val[k]])+1);
            // //     }
            // //     k++;
            // // }
            // // for(var i=COLs_a;i<COLUMNS;i++){
            // //     soroban.clickHeavenElement(i);
            // // }

            //$("#ex1").trigger("change");
            //$("#ex2").trigger("change");
            //$(".cal_result").hide();
            // // soroban.calculate();
            
            //location.reload();
            
            var origin = window.location.origin;
            var pathname = window.location.pathname;
            
            //console.log(origin);
            //console.log(pathname);
            
            
            
            var input = $("input:radio");
            for(i=0;i<input.length;i++){
                if(input[i].checked){
                    var opt = operator[input[i].id];
                    // console.log('opt='+opt);
                }
            }            

            //console.log($("input:radio option:selected").text()+' <----aqui!');
            //console.log($("input[name=optradio]:checked").val());
            
            var url = origin + pathname + '?dig1=' + $("#ex1").val() + '&dig2=' + $("#ex2").val() + '&opt=' + opt;
            
            //console.log(url);
            
            //$('.row-soroban').html($divClone);
            
            //window.location.href=url;

                $("#soroban").text('');
                soroban.init();
                $("#cal_result").text('');
                //hide Result button
                $(".btn-success").show();
                
                //show Reset button
                $(".btn-danger").hide();
                
                //show result area
                $(".cal_result").hide();

                //generate new results
                $("#ex1").change();
                $("#ex2").change();

                console.log('fim do calculate');
            
        })
        
        $("input[type=radio][name=optradio]").change(function(e){
            $("#ex1").change();
            $("#ex2").change();
        })
    },
    clickEarthElement: function (column, row) {
        var moved = parseInt(this.els[column][row].attr("data-moved")) == 1;
        //console.log('ssssssss',moved);
        if (moved) {
            //noinspection JSDuplicatedDeclaration
            for (var j = EARTH_ELEMENTS_COUNT ; j >= row; j--) {
                if (parseInt(this.els[column][j].attr("data-moved")) == 0) {
                    continue;
                }
                //noinspection JSDuplicatedDeclaration
                var top = parseInt(this.els[column][j].css("top"));
                top += DELTA;
                this.els[column][j].css("top", top);
                this.els[column][j].attr("data-moved", moved ? 0 : 1);
            }
        } else {
            //noinspection JSDuplicatedDeclaration
            for (var j = 0; j <= row; j++) {
                if (parseInt(this.els[column][j].attr("data-moved")) == 1) {
                    continue;
                }
                //noinspection JSDuplicatedDeclaration
                // console.log(this.els);
                var top = parseInt(this.els[column][j].css("top"));
                top -= DELTA;
                this.els[column][j].css("top", top);
                this.els[column][j].attr("data-moved", moved ? 0 : 1);
            }
        }
    },

    clickHeavenElement: function (column) {
        var top = parseInt(this.els[column][EARTH_ELEMENTS_COUNT].css("top"));
        var moved = parseInt(this.els[column][EARTH_ELEMENTS_COUNT].attr("data-moved")) == 1;
        var coeff = moved ? -1 : 1;
        top += coeff * DELTA;
        this.els[column][EARTH_ELEMENTS_COUNT].css("top", 64);
        this.els[column][EARTH_ELEMENTS_COUNT].attr("data-moved", moved ? 0 : 1);
        // top = 0;
    }
};

$(document).ready(function () {
    console.log('entrou no document ready')

    // $(".btn-success").click(function(){
    //     console.log(mov_val);

    // })


    //get URL parameters to config site
    var getUrlParameter = function getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');

            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
    };
    
    var dig1 = getUrlParameter('dig1');
    var dig2 = getUrlParameter('dig2');
    var opt = getUrlParameter('opt');
    //    console.log(dig1);
    //    console.log(dig2);
    //    console.log(opt);

    //if there is no parameters in the URL, configute site
    if(dig1!=undefined) {
        $("#ex1").val(dig1);
        $("#ex2").val(dig2);
        opt = opt=='+'?'plus':opt=='-'?'minus':opt=='*'?'multiply':opt=='/'?'divide':opt;
        $("#"+opt).prop('checked', true);
        //$("#minus").prop('checked', true);

        //console.log (opt);
    }


    


    
    
    soroban.init();

    $("#ex1").keyup(function(){
        $("#ex1").change()
    });
    
    $("#ex2").keyup(function(){
        $("#ex2").change()
    });
    
    $("#ex1").change()
    $("#ex2").change()
    
    $divClone = $(".col-md-12").clone();

    
});







